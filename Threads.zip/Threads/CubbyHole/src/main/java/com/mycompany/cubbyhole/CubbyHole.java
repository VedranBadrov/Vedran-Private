/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.cubbyhole;

/**
 *
 * @author cmuntean
 */

// Unsynchronized CubbyHole.
//
// Results are unpredictable; a number may be read before a number
// has been produced or multiple numbers may be produced with only
// one or two being read adding synchronization ensures that a number 
// is first produced, then read in the correct order.
public class CubbyHole {
    private int contents;
    private boolean available = false;

    public int get() {
        available = false;
        return contents;
    }

    public void put(int value) {
        contents = value;
        available = true;
    }
}
