/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.cubbyhole_synchronized;

/**
 *
 * @author cmuntean
 */

// Synchronized CubbyHole.
public class CubbyHole {
    private int contents;
    private boolean available = false;

    public synchronized int get(int who) {
    while (this.available == false) {
      try {
        wait();
      } catch (InterruptedException e) {
      }
    }
    this.available = false;
    System.out.println("Consumer " + who + " is getting: " + this.contents);
    notifyAll();
    return this.contents;
  }

  public synchronized void put(int who, int value) {
    while (this.available == true) {
      try {
        wait();
      } catch (InterruptedException e) {
      }
    }
    this.contents = value;
    this.available = true;
    System.out.println("Producer " + who + " is putting: " + this.contents);
    notifyAll();
  }
}
