/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.ipaddrdemo;
import java.net.*;

/**
 *
 * @author cmuntean
 */
public class IPAddrDemo {
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println (" Looking up the IP address of the local host ");
        try 
        {
            // Get the local host
            InetAddress localAddress = InetAddress.getLocalHost ();
            
            System.out.println("IP address of this machine : "+ localAddress.getHostAddress ());
        } 
        catch ( Exception ex ) 
        {
            System.out.println (" Error - unable to resolve localhost ");
        }
    }
}
