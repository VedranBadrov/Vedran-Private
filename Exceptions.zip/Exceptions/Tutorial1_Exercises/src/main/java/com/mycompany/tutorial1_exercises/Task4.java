/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.tutorial1_exercises;

/**
 *
 * @author cmuntean
 */
import java.util.InputMismatchException;
import java.util.Scanner;

public class Task4 {

    public static void main(String[] args) {
        try {
            Scanner keyboard = new Scanner(System.in);

            System.out.println("Enter the number of Stuff: ");
            int num = keyboard.nextInt();
            
            long r  = Math.round(Math.random() * 100);
            if (num > r) {
                throw new TooManyStuffException("Random number is " + r);
            }
            System.out.println("Reasonable number of stuff!");
        } catch (InputMismatchException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (TooManyStuffException e) {
            System.out.println("Error: " + e.getTooManyMessages());
        }
    }
}

