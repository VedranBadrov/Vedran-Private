/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lab2_part1;

/**
 *
 * @author cmuntean
 */
public class Task3 {
    public static void main(String args[]) {
        Runnable r1 = new WordsThreadRun("First", 4);
        Runnable r2 = new WordsThreadRun("Second", 4);
    Thread first = new Thread(r1);
    Thread second = new Thread(r2);

    first.setPriority(1);
    second.setPriority(2);

    second.start();
    first.start();
  }
}
