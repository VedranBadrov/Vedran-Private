/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lab2_part1;

/**
 *
 * @author cmuntean
 */
public class Task1 {
  public static void main(String args[]) {
    for (int i = 1; i < 10; i++) {
      Thread x = new Thread();
      System.out.println("Thread ID is: "+ x.getId());
      System.out.println("Thread Name is: "+x.getName());
    }
  }
    
}
