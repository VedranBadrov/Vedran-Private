/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.tutorial1_exercises;

/**
 *
 * @author cmuntean
 */
import java.util.InputMismatchException;
import java.util.Scanner;

public class Task3 {

    public static void main(String[] args) {

        try {
            System.out.println("Enter a number: ");
            Scanner keyboard = new Scanner(System.in);
            float number = keyboard.nextFloat();

            if (number < 0) {
                throw new ArithmeticException("Cannot perform this operation with a negative number");
            }
            System.out.println("The squared root is " + Math.sqrt(number));
        } 
        catch (ArithmeticException e) {
            System.out.println(e.getMessage());
        } 
        catch (InputMismatchException e) {
            System.out.println("Input Mismatch Error");
        }
    }
}
