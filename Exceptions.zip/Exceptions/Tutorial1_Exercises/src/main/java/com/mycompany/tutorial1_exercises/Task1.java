/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.tutorial1_exercises;

/**
 *
 * @author cmuntean
 */
import java.util.InputMismatchException;
import java.util.Scanner;

public class Task1 {

    public static void main(String[] args) {
        int a = 0;
        int b = 0;

        boolean notOk;
        do {
            notOk = false;
            try {
                Scanner keyboard = new Scanner(System.in);
                System.out.println("Enter an integer number: ");
                a = keyboard.nextInt();
            } catch (InputMismatchException e) {
                notOk = true;
                System.out.println("Wrong number! Try again. ");
            } finally {
                System.out.println();
            }
        } while (notOk);

        do {
            notOk = false;
            try {
                System.out.println("Enter another integer number: ");
                Scanner keyboard = new Scanner(System.in);
                b = keyboard.nextInt();
            } catch (InputMismatchException e) {
                notOk = true;
                System.out.println("Wrong number! Try again. ");
            } finally {
                System.out.println();
            }
        } while (notOk);

        System.out.println("The sum is " + (a + b));
    }
}

