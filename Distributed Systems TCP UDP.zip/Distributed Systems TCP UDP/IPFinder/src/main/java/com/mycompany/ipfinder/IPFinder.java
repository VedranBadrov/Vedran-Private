/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.ipfinder;
import java.net .*;
import java.io .*;

/**
 *
 * @author cmuntean
 */
public class IPFinder {
    public static void main(String[] args) {
        String host ;
        BufferedReader input = new BufferedReader (new InputStreamReader (System.in));
        System.out.println (" Enter host name : ");
        try 
        {
            host = input.readLine();
            InetAddress address = InetAddress.getByName(host);
            System.out. println ("IP address : " + address.toString ());
        }
        catch (Exception ex) 
        {  
            System.err.println(ex);  
        }  
    }      
}
