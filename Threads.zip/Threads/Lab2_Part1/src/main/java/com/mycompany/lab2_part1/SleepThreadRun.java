/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lab2_part1;

/**
 *
 * @author cmuntean
 */
public class SleepThreadRun implements Runnable {
    
  private int delay;

  public SleepThreadRun(int delayTime) {
    this.delay = delayTime;
  }

  public void run() {
    try {
      Thread.sleep(this.delay);
    } catch (InterruptedException e) {
      return;
    }
  }
    
}
